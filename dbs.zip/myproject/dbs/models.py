from django.db import models
from datetime import date

class Stock(models.Model):
    stockName=models.TextField()
    stockStatus=models.BooleanField(default=False)

ORDER_TYPE=(
    ('Limit','Limit'),
    ('Market','Market'),
)

ORDER_STATUS=(
    ('ACCEPTED','ACCEPTED'),
    ('PLACED','PLACED'),
    ('PROCESSED','PROCESSED'),
    ('REJECTED','REJECTED'),
)

class order(models.Model):
    stock=models.ForeignKey(Stock,on_delete=models.CASCADE)
    order_quantity=models.PositiveIntegerField(default=0)
    order_type=models.CharField(choices=ORDER_TYPE,max_length=100)
    executed_quantity=models.PositiveIntegerField(default=0)
    order_status=models.CharField(choices=ORDER_STATUS,max_length=100)
    price=models.IntegerField(default=0)
    order_date=models.DateField(default=date.today)
    