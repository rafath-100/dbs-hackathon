from django.contrib import admin
from .models import Stock,order
admin.site.register(Stock)
admin.site.register(order)

# Register your models here.
