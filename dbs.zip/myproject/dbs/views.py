from django.contrib.auth.models import User,auth
from django.shortcuts import render,redirect
from dbs.models import Stock,order

def index(request):
    return render(request,'index.html')